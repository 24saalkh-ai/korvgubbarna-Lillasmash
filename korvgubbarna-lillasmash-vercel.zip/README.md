# Korvgubbarna och Lilla Smash 🍔🌭
Söder Mälarstrand 55, Stockholm. Telefon: 070-033 31 13.

## Driftsättning till Vercel:
1. Skapa ett nytt repo på GitHub och ladda upp dessa filer.
2. Gå till https://vercel.com/new och importera repot.
3. Klicka på "Deploy" så är hemsidan live på några sekunder!